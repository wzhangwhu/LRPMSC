function [Zn, error] = LRPMSC(X,lambda1,lambda2,p,maxIter)

V = length(X);
n = size(X{1}, 2); % 样本数；维数：feature*sample
mu = 1e-2; % 1e-2
rho = 2.8; % 2.8
mu_max = 1e8; % 1e8

%% d的取值
for v = 1:V
    m(v) = size(X{v}, 1); % 特征数
end
minfea = min(m);
if minfea < 30
    d = minfea;
else
    d = 30;
end
%% initialization
C = zeros(n,n);
for v = 1:V
    Z{v} = zeros(n,n);
    J{v} = zeros(n,n);
    R{v} = zeros(n,n);
    P{v} = zeros(m(v),d);
    W{v} = zeros(n,n);
    I{v} = eye(n,n);
    Q1{v} = zeros(size(X{v}));
    Q2{v} = zeros(n,n);
    Q3{v} = zeros(n,n);
    Q4{v} = zeros(n,n);
end
%% optimization
for iter = 1:maxIter
%     iter
    CC = zeros(n,n);
    %% ------------------- Update E ---------------------------
    for v = 1:V
        tempE = X{v}-X{v}*Z{v}+Q1{v}/mu;
        for i=1:n
            nw = norm(tempE(:,i));
            if nw>lambda2/mu
                x = (nw-lambda2/mu)*tempE(:,i)/nw;
            else
                x = zeros(length(tempE(:,i)),1);
            end
            tempE(:,i) = x;
        end
        E{v} = tempE; % m*n
    end
    
    %% ------------------- Update L、R ---------------------
    for v = 1:V
        tempL = (Q2{v}/mu+Z{v})*R{v}*C';
        [u,~,vv] = svd(tempL,'econ');
        L{v} = u*vv';
        
        tempR = (Q2{v}/mu+Z{v})'*L{v}*C;
        [u,~,vv] = svd(tempR,'econ');
        R{v} = u*vv';
    end
    
    %% ------------------- Update Z ---------------------------
    for v = 1:V
        M1{v} = X{v}-E{v}+Q1{v}/mu;
        M2{v} = L{v}*C*R{v}'-Q2{v}/mu;
        M3{v} = J{v}-Q3{v}/mu;
        M4{v} = W{v}-Q4{v}/mu;
        tempZ = X{v}'*X{v}+3*I{v};
        Z{v} = tempZ\(X{v}'*M1{v}+M2{v}+M3{v}+M4{v});
        CC = CC + L{v}'*(Q2{v}/mu+Z{v})*R{v};
    end
    
    %% ------------------- Update J -----------------------
    for v = 1:V
        JJ = Z{v} + Q3{v}/mu;
        J{v} = (JJ + JJ') / 2;
    end
    %% ------------------- Update P -----------------------------
    for v = 1:V
        D{v} = diag(sum(W{v}, 2));
        L1{v} = D{v}-W{v};
        LL{v} = lambda1*X{v}*L1{v}*X{v}';
        epsilon = 1e-12; % 使矩阵非奇异
        LL{v} = LL{v} + epsilon * eye(size(LL{v})); 
        [P{v}, ~, ~] = eig1(LL{v}, d, 0);
    end
    %% ------------------- Update W -----------------------
    for v = 1:V
        for i = 1:n
            for j = 1:n
                PP = P{v}'*X{v}(:,i)-P{v}'*X{v}(:,j);
                Y{v}(i,j) = norm(PP, 2)^2;
            end
        end
        T{v} = Z{v}+Q4{v}/mu;
        W{v} = T{v}-lambda1*Y{v}/mu;
    end
  
    %% ------------------- Update C -----------------------------
    [UUU,sigma,VVV] = svd(CC/V,'econ');
    sigma = diag(sigma);
    xi = spw(sigma,1/(V*mu),p);
    C = UUU*diag(xi)*VVV';
    
    %% ---------------- Update Q1,Q2,Q3,Q4 --------------
    for v = 1:V   
        Q1{v} = Q1{v}+mu*(X{v}-X{v}*Z{v}-E{v});
        Q2{v} = Q2{v}+mu*(Z{v}-L{v}*C*R{v}');
        Q3{v} = Q3{v}+mu*(Z{v}-J{v});
        Q4{v} = Q4{v}+mu*(Z{v}-W{v});
    end
    mu = min(rho*mu,mu_max);

    %% Stop
    for v = 1:V
        tempstop = Z{v} - L{v}*C*R{v}';
        temp_ter1(v) = max(max(abs(tempstop)));
    end
    stop = max(temp_ter1);
    error(iter) = stop;
    if abs(stop)<0.01
        break
    end    
    disp(['iter' num2str(iter) 'stop' num2str(stop)])

end

Zn = zeros(n, n);
for v = 1 : V
    Zn = Zn + Z{v};
end

end